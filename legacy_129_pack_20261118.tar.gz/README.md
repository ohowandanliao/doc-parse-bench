# legacy_129 双层结果包（2026-11-18）

129 篇 legacy_129 批次的**机标链 + 人标快照**双层结果，取自 live tree（10.57.1.91 viewer 数据）当日状态。

## 内容

| 目录 | 内容 | 规模 |
|---|---|---:|
| `runs/<sid>/page_NNNN/result.json` | 机标链（引擎逐层候选 + revision.blocks） | 372 页，2.8MB |
| `annotations/<sid>/page_NNNN.json` | 人标整页快照（有则整页替换） | 314 页，6.3MB |
| `annotations/<sid>/document.json` | 文档级状态（review_confirm verdict/note/by/at） | 129 份 |
| `manifest.csv` | sample_id, pages, patch_pages, runs_bytes, anno_bytes | 129 行 |

## 合成口径（与 viewer 一致）

**每页 Final = 有 patch 用 patch.blocks 整页替换；无 patch 用链上 result.json 的 revision.blocks。**

- patch 是整页快照（非 diff）；patch 层 table=HTML、formula=LaTeX，链路层同字段
- 372 − 314 = 58 页为纯机标链页（无人碰过）
- document.json 的 review_confirm：129 篇全部 verdict=ok（11-13~17 确认）
- 块字段：block_id / type / level / text / html / bbox_normalized / bbox_pdf_pt / reading_order

## 来源

- live tree：`/mnt/lvm/docfusion_io/benchmark/annotated_gt/legacy_129/{runs,annotations}`
- 源 PDF 与页图不在此包内；源 PDF 见 `annotated_gt_full282_20261118/sources/`（bc_*.pdf，md5 对账过）或批次内 doc 文档夹
